﻿
Partial Class Employee
    Inherits System.Web.UI.Page

    Protected Sub ddlEmps_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlEmps.SelectedIndexChanged
        lblInfo.Text = ddlEmps.SelectedValue.ToString & "-" & ddlEmps.SelectedItem.ToString
    End Sub

End Class
