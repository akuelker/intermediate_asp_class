﻿
Partial Class ProdSearch
    Inherits System.Web.UI.Page

End Class
