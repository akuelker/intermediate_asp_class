﻿
Partial Class ProdSelect
    Inherits System.Web.UI.Page
  
    Protected Sub ddlPartNum_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlPartNum.SelectedIndexChanged
        lblPartDisp.Text = "You selected part number " & ddlPartNum.SelectedValue.ToString
        blAuto.DataTextField = ddlPartNum.SelectedValue.ToString
    End Sub
End Class
