﻿
Partial Class ProdSelect
    Inherits System.Web.UI.Page

    Protected Sub ddlParts_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlParts.SelectedIndexChanged
        lblInfo.Text = ddlParts.SelectedValue.ToString
    End Sub
End Class
