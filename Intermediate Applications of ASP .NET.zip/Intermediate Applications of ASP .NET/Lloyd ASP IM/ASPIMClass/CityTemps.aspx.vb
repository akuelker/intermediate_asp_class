﻿
Partial Class CityTemps
    Inherits System.Web.UI.Page

    Protected Sub RadioButtonList1_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles RadioButtonList1.SelectedIndexChanged
        Dim strInfo() As String =
            Split(RadioButtonList1.SelectedValue, "-")

        lblCityTemp.Text = strInfo(0) & "<br />" &
            strInfo(1) & "&deg;" & "F"
    End Sub
End Class
