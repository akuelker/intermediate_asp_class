﻿
Partial Class employee
    Inherits System.Web.UI.Page

    Protected Sub ddlEmps_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlEmps.SelectedIndexChanged, RadioButtonList1.SelectedIndexChanged
        lblInfo.Text = sender.SelectedItem.ToString & "-" &
            sender.SelectedValue.ToString
    End Sub
End Class
