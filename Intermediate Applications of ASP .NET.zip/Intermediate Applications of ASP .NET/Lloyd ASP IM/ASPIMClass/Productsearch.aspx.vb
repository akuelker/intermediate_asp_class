﻿
Partial Class Productsearch
    Inherits System.Web.UI.Page

    Protected Sub AccessDataSource1_Selecting(sender As Object, e As System.Web.UI.WebControls.SqlDataSourceSelectingEventArgs) Handles AccessDataSource1.Selecting

    End Sub
End Class
