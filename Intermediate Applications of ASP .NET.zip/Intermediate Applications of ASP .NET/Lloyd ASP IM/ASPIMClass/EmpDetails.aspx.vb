﻿
Partial Class EmpDetails
    Inherits System.Web.UI.Page

End Class
