﻿
Partial Class ProdDetails
    Inherits System.Web.UI.Page

End Class
