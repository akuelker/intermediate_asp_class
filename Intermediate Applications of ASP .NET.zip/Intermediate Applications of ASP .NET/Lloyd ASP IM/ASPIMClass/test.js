﻿function SayHello()
{
    alert("Hello World");
}