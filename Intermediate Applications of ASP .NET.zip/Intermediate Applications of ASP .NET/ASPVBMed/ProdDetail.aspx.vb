
Partial Class ProdDetail
    Inherits System.Web.UI.Page

End Class
