
Partial Class EmpSelect
    Inherits System.Web.UI.Page

    Protected Sub ddlEmps_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlEmps.SelectedIndexChanged, rblEmps.SelectedIndexChanged
        lblOutput.Text = sender.SelectedItem.Text & "-" & sender.SelectedValue
    End Sub
End Class
