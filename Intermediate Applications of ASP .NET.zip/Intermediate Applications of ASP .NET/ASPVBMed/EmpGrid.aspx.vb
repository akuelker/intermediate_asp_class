
Partial Class EmpGrid
    Inherits System.Web.UI.Page

End Class
