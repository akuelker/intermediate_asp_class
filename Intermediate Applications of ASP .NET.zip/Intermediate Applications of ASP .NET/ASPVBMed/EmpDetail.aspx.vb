
Partial Class EmpDetail
    Inherits System.Web.UI.Page

End Class
